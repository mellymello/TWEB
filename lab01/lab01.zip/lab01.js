function showAlert() {
    alert("Hello");
}

function init() {
    var date = new Date();
    $('.clock').text(date);
}

function Person(fn, ln, g) {
    this.firstName = fn;
    this.lastName = ln;
    this.gender = g;
}
Person.prototype.getLabel = function () {
    return "Hello " + this.firstName + " " + this.lastName + "( " + this.gender + " )";
}

function name() {
    var gender = chance.gender();
    var fn = chance.first({
        gender: gender
    });
    var ln = chance.last({
        gender: gender
    });
    var p = new Person(fn, ln, gender);
    $('.name').text(p.getLabel());
    if (gender === "Male") {
        $('.bgcolor').css("background-color", "lightblue");
        $('.bgcolor').css("color", "blue");
    } else {
        $('.bgcolor').css("background-color", "pink");
        $('.bgcolor').css("color", "red");
    }
}
var isHidden = false;

function toggle() {
    if (isHidden === false) {
        $("#namePan").hide("slow");
        isHidden = true;
    } else {
        $("#namePan").show("fast");
        isHidden = false;
    }
}

function showRoom() {
    $.getJSON('room.json', function (jd) {
        $('#room').html('<p> Nombre: ' + jd.nbr + '</p>');
        $('#room').append('<p>Place : ' + jd.place + '</p>');
    });
}

/*p = Person()

function Robot() {
    
    var counter = 0;
    
    this.name;
    
    this.incCounter = function() {
        counter++;
    }
    
    this.decCounter = function() {
        counter--;
    }
    
    this.getCounter = function() {
        return counter;
    }
    
}

Robot.prototype.fight = function() {
    //genericc fight
}

var r1 = new Robot();

var f = function() {}

Robot.prototype.fight = f;*/